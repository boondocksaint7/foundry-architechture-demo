import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace ShipmentException {
    type PropertyKeys = 'acknowledgedAt' | 'acknowledgedBy' | 'actionNote' | 'assignedTo' | 'assignedUserId' | 'createdTimestamp' | 'exceptionCode' | 'exceptionDescription' | 'exceptionEventId' | 'exceptionType' | 'isCritical' | 'isOpen' | 'isResolved' | 'locationId' | 'resolution' | 'resolvedAt' | 'resolvedBy' | 'severity' | 'severityRank' | 'shipmentId' | 'status';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Acknowledged At'
         */
        readonly acknowledgedAt: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Acknowledged By'
         */
        readonly acknowledgedBy: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Latest Note',
         *
         *   description: Free-text note captured by the most recent operator action on this exception.
         */
        readonly actionNote: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned To'
         */
        readonly assignedTo: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned Owner',
         *
         *   description: Foundry user who owns this exception, set by the Assign Exception action. Distinct from the free-text assigned_to name that arrives in the source feed.
         */
        readonly assignedUserId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Raised At'
         */
        readonly createdTimestamp: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Exception Code'
         */
        readonly exceptionCode: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Description'
         */
        readonly exceptionDescription: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Exception Event ID'
         */
        readonly exceptionEventId: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Exception Type',
         *
         *   description: Plain-language classification, for example Vehicle Breakdown or Customs Hold.
         */
        readonly exceptionType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Critical'
         */
        readonly isCritical: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Open',
         *
         *   description: OPEN or ACKNOWLEDGED, i.e. still requiring attention.
         */
        readonly isOpen: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Resolved'
         */
        readonly isResolved: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Location ID'
         */
        readonly locationId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Resolution'
         */
        readonly resolution: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Resolved At'
         */
        readonly resolvedAt: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Resolved By'
         */
        readonly resolvedBy: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Severity',
         *
         *   description: CRITICAL, HIGH, MEDIUM or LOW. Event severity overrides the code default.
         */
        readonly severity: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Severity Rank',
         *
         *   description: 1 = CRITICAL through 4 = LOW, for sorting.
         */
        readonly severityRank: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Shipment ID'
         */
        readonly shipmentId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Status',
         *
         *   description: OPEN, ACKNOWLEDGED or RESOLVED.
         */
        readonly status: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<ShipmentException, ShipmentException.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof ShipmentException.Props = keyof ShipmentException.Props> = $Osdk.Instance<ShipmentException, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof ShipmentException.Props = keyof ShipmentException.Props> = OsdkInstance<OPTIONS, K>;
}
export interface ShipmentException extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'ShipmentException';
    primaryKeyApiName: 'exceptionEventId';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: ShipmentException.ObjectSet;
        props: ShipmentException.Props;
        linksType: ShipmentException.Links;
        strictProps: ShipmentException.StrictProps;
        apiName: 'ShipmentException';
        description: 'An operational incident raised against a shipment, such as a vehicle breakdown, weather delay, customs hold or damaged package. Carries severity, workflow status and owner, and is the primary work item for an exceptions desk.';
        displayName: 'Shipment Exception';
        icon: {
            type: 'blueprint';
            color: '#D9822B';
            name: 'warning-sign';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'Shipment Exceptions';
        primaryKeyApiName: 'exceptionEventId';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Acknowledged At'
             */
            acknowledgedAt: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Acknowledged By'
             */
            acknowledgedBy: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Latest Note',
             *
             *   description: Free-text note captured by the most recent operator action on this exception.
             */
            actionNote: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned To'
             */
            assignedTo: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned Owner',
             *
             *   description: Foundry user who owns this exception, set by the Assign Exception action. Distinct from the free-text assigned_to name that arrives in the source feed.
             */
            assignedUserId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Raised At'
             */
            createdTimestamp: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Exception Code'
             */
            exceptionCode: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Description'
             */
            exceptionDescription: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Exception Event ID'
             */
            exceptionEventId: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Exception Type',
             *
             *   description: Plain-language classification, for example Vehicle Breakdown or Customs Hold.
             */
            exceptionType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Critical'
             */
            isCritical: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Open',
             *
             *   description: OPEN or ACKNOWLEDGED, i.e. still requiring attention.
             */
            isOpen: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Resolved'
             */
            isResolved: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Location ID'
             */
            locationId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Resolution'
             */
            resolution: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Resolved At'
             */
            resolvedAt: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Resolved By'
             */
            resolvedBy: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Severity',
             *
             *   description: CRITICAL, HIGH, MEDIUM or LOW. Event severity overrides the code default.
             */
            severity: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Severity Rank',
             *
             *   description: 1 = CRITICAL through 4 = LOW, for sorting.
             */
            severityRank: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Shipment ID'
             */
            shipmentId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Status',
             *
             *   description: OPEN, ACKNOWLEDGED or RESOLVED.
             */
            status: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.27dbf4bc-d7fb-49a4-a5fb-54f5fdceaa5f';
        status: 'EXPERIMENTAL';
        titleProperty: 'exceptionType';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const ShipmentException: ShipmentException;
