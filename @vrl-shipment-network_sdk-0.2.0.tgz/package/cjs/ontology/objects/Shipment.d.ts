import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace Shipment {
    type PropertyKeys = 'actualDeliveryTs' | 'actualTransitHours' | 'assignedAt' | 'assignedBy' | 'assignedDriverId' | 'assignedVehicleId' | 'assignmentNote' | 'assignmentReason' | 'chargeableWeightKg' | 'currentEtaTs' | 'customerId' | 'customerIndustry' | 'customerName' | 'customerSegment' | 'declaredValue' | 'delayHours' | 'deliveryAttemptCount' | 'destinationCity' | 'destinationLatitude' | 'destinationLocationId' | 'destinationLocationName' | 'destinationLongitude' | 'driverCost' | 'etaVarianceHours' | 'exceptionCount' | 'fuelCost' | 'handlingCost' | 'hasException' | 'hasOpenException' | 'healthStatus' | 'insuranceCost' | 'isCancelled' | 'isDelivered' | 'isInFlight' | 'isLate' | 'isProfitable' | 'lastKnownEventType' | 'lastKnownGeoPoint' | 'lastTrackingTs' | 'latestDriverId' | 'latestExceptionType' | 'latestVehicleId' | 'margin' | 'marginPct' | 'openExceptionCount' | 'originCity' | 'originLatitude' | 'originLocationId' | 'originLocationName' | 'originLongitude' | 'packageCount' | 'plannedDeliveryTs' | 'plannedTransitHours' | 'priority' | 'revenue' | 'serviceId' | 'serviceName' | 'shipmentDate' | 'shipmentId' | 'slaBreachFlag' | 'slaHours' | 'status' | 'tollCost' | 'totalCost' | 'trackingEventCount' | 'volumeM3' | 'warehouseCost' | 'weightKg' | 'worstSeverity';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Actual Delivery'
         */
        readonly actualDeliveryTs: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Actual Transit'
         */
        readonly actualTransitHours: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned At'
         */
        readonly assignedAt: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned By'
         */
        readonly assignedBy: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned Driver',
         *
         *   description: Driver an operator has assigned to this shipment. Operator-owned and written by the Reassign Vehicle action.
         */
        readonly assignedDriverId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned Vehicle',
         *
         *   description: Vehicle an operator has assigned to this shipment. Operator-owned and written by the Reassign Vehicle action; the pipeline never touches it. Compare with Last Executed Vehicle, which is derived from delivery attempts.
         */
        readonly assignedVehicleId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assignment Note',
         *
         *   description: Operator note captured at the time of reassignment.
         */
        readonly assignmentNote: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assignment Reason',
         *
         *   description: Why the vehicle or driver was reassigned.
         */
        readonly assignmentReason: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Chargeable Weight',
         *
         *   description: Greater of actual and volumetric weight (1 m3 = 167 kg).
         */
        readonly chargeableWeightKg: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Current ETA',
         *
         *   description: Actual delivery if landed, otherwise the latest re-planned arrival, otherwise the original promise.
         */
        readonly currentEtaTs: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Customer ID'
         */
        readonly customerId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Customer Industry'
         */
        readonly customerIndustry: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Customer'
         */
        readonly customerName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Customer Segment'
         */
        readonly customerSegment: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Declared Value'
         */
        readonly declaredValue: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Delay',
         *
         *   description: Hours late against the promised delivery. Null until the shipment lands.
         */
        readonly delayHours: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Delivery Attempts'
         */
        readonly deliveryAttemptCount: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Destination City'
         */
        readonly destinationCity: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Destination Latitude'
         */
        readonly destinationLatitude: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Destination Location ID'
         */
        readonly destinationLocationId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Destination'
         */
        readonly destinationLocationName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Destination Longitude'
         */
        readonly destinationLongitude: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Driver Cost'
         */
        readonly driverCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'ETA Variance',
         *
         *   description: Hours the current ETA runs beyond the original promised delivery. Negative is early.
         */
        readonly etaVarianceHours: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Exception Count'
         */
        readonly exceptionCount: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Fuel Cost'
         */
        readonly fuelCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Handling Cost'
         */
        readonly handlingCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Has Exception'
         */
        readonly hasException: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Has Open Exception'
         */
        readonly hasOpenException: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Health Status',
         *
         *   description: Derived triage state: CANCELLED, DELIVERED_ON_TIME, DELIVERED_LATE, AT_RISK_EXCEPTION, AT_RISK_LATE or ON_TRACK.
         */
        readonly healthStatus: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Insurance Cost'
         */
        readonly insuranceCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Cancelled'
         */
        readonly isCancelled: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Delivered'
         */
        readonly isDelivered: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is In Flight',
         *
         *   description: Not yet delivered or cancelled.
         */
        readonly isInFlight: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Late'
         */
        readonly isLate: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Profitable'
         */
        readonly isProfitable: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Last Known Event'
         */
        readonly lastKnownEventType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Last Known Position',
         *
         *   description: Coordinates of the most recent tracking scan.
         */
        readonly lastKnownGeoPoint: $PropType['geopoint'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Last Scan'
         */
        readonly lastTrackingTs: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Last Executed Driver ID',
         *
         *   description: Driver on the most recent delivery attempt. Derived by the pipeline and recomputed each build.
         */
        readonly latestDriverId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Latest Exception Type'
         */
        readonly latestExceptionType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Last Executed Vehicle ID',
         *
         *   description: Vehicle on the most recent delivery attempt. Derived by the pipeline from fact_delivery and recomputed each build, so it reflects what actually happened rather than what an operator assigned.
         */
        readonly latestVehicleId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Margin',
         *
         *   description: Revenue less total cost.
         */
        readonly margin: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Margin %',
         *
         *   description: Margin as a percentage of revenue.
         */
        readonly marginPct: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Open Exception Count'
         */
        readonly openExceptionCount: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Origin City'
         */
        readonly originCity: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Origin Latitude'
         */
        readonly originLatitude: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Origin Location ID'
         */
        readonly originLocationId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Origin'
         */
        readonly originLocationName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Origin Longitude'
         */
        readonly originLongitude: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Package Count'
         */
        readonly packageCount: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Planned Delivery'
         */
        readonly plannedDeliveryTs: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Planned Transit'
         */
        readonly plannedTransitHours: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Priority'
         */
        readonly priority: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Revenue',
         *
         *   description: Shipping charge billed to the customer.
         */
        readonly revenue: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Service ID'
         */
        readonly serviceId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Service'
         */
        readonly serviceName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Shipment Date'
         */
        readonly shipmentDate: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Shipment ID'
         */
        readonly shipmentId: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'SLA Breached',
         *
         *   description: Actual transit time exceeded the service SLA window.
         */
        readonly slaBreachFlag: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'SLA'
         */
        readonly slaHours: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Status',
         *
         *   description: Lifecycle state from the source system.
         */
        readonly status: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Toll Cost'
         */
        readonly tollCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Total Cost',
         *
         *   description: Sum of all cost lines booked against the shipment.
         */
        readonly totalCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Tracking Event Count'
         */
        readonly trackingEventCount: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Volume'
         */
        readonly volumeM3: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Warehouse Cost'
         */
        readonly warehouseCost: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Weight'
         */
        readonly weightKg: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Worst Severity',
         *
         *   description: Highest exception severity raised against the shipment.
         */
        readonly worstSeverity: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<Shipment, Shipment.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof Shipment.Props = keyof Shipment.Props> = $Osdk.Instance<Shipment, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof Shipment.Props = keyof Shipment.Props> = OsdkInstance<OPTIONS, K>;
}
export interface Shipment extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'Shipment';
    primaryKeyApiName: 'shipmentId';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: Shipment.ObjectSet;
        props: Shipment.Props;
        linksType: Shipment.Links;
        strictProps: Shipment.StrictProps;
        apiName: 'Shipment';
        description: 'A consignment moved by VRL Logistics from an origin to a destination under a service level agreement. This is the central operational object: it carries commercial measures (revenue, cost, margin), promise-versus-reality measures (current ETA, delay, SLA breach), exception exposure and last known position, all rolled up from the underlying cost, delivery and tracking facts.';
        displayName: 'Shipment';
        icon: {
            type: 'blueprint';
            color: '#A66321';
            name: 'box';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'Shipments';
        primaryKeyApiName: 'shipmentId';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Actual Delivery'
             */
            actualDeliveryTs: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Actual Transit'
             */
            actualTransitHours: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned At'
             */
            assignedAt: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned By'
             */
            assignedBy: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned Driver',
             *
             *   description: Driver an operator has assigned to this shipment. Operator-owned and written by the Reassign Vehicle action.
             */
            assignedDriverId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned Vehicle',
             *
             *   description: Vehicle an operator has assigned to this shipment. Operator-owned and written by the Reassign Vehicle action; the pipeline never touches it. Compare with Last Executed Vehicle, which is derived from delivery attempts.
             */
            assignedVehicleId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assignment Note',
             *
             *   description: Operator note captured at the time of reassignment.
             */
            assignmentNote: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assignment Reason',
             *
             *   description: Why the vehicle or driver was reassigned.
             */
            assignmentReason: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Chargeable Weight',
             *
             *   description: Greater of actual and volumetric weight (1 m3 = 167 kg).
             */
            chargeableWeightKg: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Current ETA',
             *
             *   description: Actual delivery if landed, otherwise the latest re-planned arrival, otherwise the original promise.
             */
            currentEtaTs: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Customer ID'
             */
            customerId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Customer Industry'
             */
            customerIndustry: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Customer'
             */
            customerName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Customer Segment'
             */
            customerSegment: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Declared Value'
             */
            declaredValue: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Delay',
             *
             *   description: Hours late against the promised delivery. Null until the shipment lands.
             */
            delayHours: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Delivery Attempts'
             */
            deliveryAttemptCount: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Destination City'
             */
            destinationCity: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Destination Latitude'
             */
            destinationLatitude: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Destination Location ID'
             */
            destinationLocationId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Destination'
             */
            destinationLocationName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Destination Longitude'
             */
            destinationLongitude: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Driver Cost'
             */
            driverCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'ETA Variance',
             *
             *   description: Hours the current ETA runs beyond the original promised delivery. Negative is early.
             */
            etaVarianceHours: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Exception Count'
             */
            exceptionCount: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Fuel Cost'
             */
            fuelCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Handling Cost'
             */
            handlingCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Has Exception'
             */
            hasException: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Has Open Exception'
             */
            hasOpenException: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Health Status',
             *
             *   description: Derived triage state: CANCELLED, DELIVERED_ON_TIME, DELIVERED_LATE, AT_RISK_EXCEPTION, AT_RISK_LATE or ON_TRACK.
             */
            healthStatus: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Insurance Cost'
             */
            insuranceCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Cancelled'
             */
            isCancelled: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Delivered'
             */
            isDelivered: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is In Flight',
             *
             *   description: Not yet delivered or cancelled.
             */
            isInFlight: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Late'
             */
            isLate: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Profitable'
             */
            isProfitable: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Last Known Event'
             */
            lastKnownEventType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Last Known Position',
             *
             *   description: Coordinates of the most recent tracking scan.
             */
            lastKnownGeoPoint: $PropertyDef<'geopoint', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Last Scan'
             */
            lastTrackingTs: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Last Executed Driver ID',
             *
             *   description: Driver on the most recent delivery attempt. Derived by the pipeline and recomputed each build.
             */
            latestDriverId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Latest Exception Type'
             */
            latestExceptionType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Last Executed Vehicle ID',
             *
             *   description: Vehicle on the most recent delivery attempt. Derived by the pipeline from fact_delivery and recomputed each build, so it reflects what actually happened rather than what an operator assigned.
             */
            latestVehicleId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Margin',
             *
             *   description: Revenue less total cost.
             */
            margin: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Margin %',
             *
             *   description: Margin as a percentage of revenue.
             */
            marginPct: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Open Exception Count'
             */
            openExceptionCount: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Origin City'
             */
            originCity: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Origin Latitude'
             */
            originLatitude: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Origin Location ID'
             */
            originLocationId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Origin'
             */
            originLocationName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Origin Longitude'
             */
            originLongitude: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Package Count'
             */
            packageCount: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Planned Delivery'
             */
            plannedDeliveryTs: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Planned Transit'
             */
            plannedTransitHours: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Priority'
             */
            priority: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Revenue',
             *
             *   description: Shipping charge billed to the customer.
             */
            revenue: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Service ID'
             */
            serviceId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Service'
             */
            serviceName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Shipment Date'
             */
            shipmentDate: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Shipment ID'
             */
            shipmentId: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'SLA Breached',
             *
             *   description: Actual transit time exceeded the service SLA window.
             */
            slaBreachFlag: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'SLA'
             */
            slaHours: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Status',
             *
             *   description: Lifecycle state from the source system.
             */
            status: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Toll Cost'
             */
            tollCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Total Cost',
             *
             *   description: Sum of all cost lines booked against the shipment.
             */
            totalCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Tracking Event Count'
             */
            trackingEventCount: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Volume'
             */
            volumeM3: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Warehouse Cost'
             */
            warehouseCost: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Weight'
             */
            weightKg: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Worst Severity',
             *
             *   description: Highest exception severity raised against the shipment.
             */
            worstSeverity: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.2261b393-cec1-482f-87b1-673cbd00ba87';
        status: 'EXPERIMENTAL';
        titleProperty: 'shipmentId';
        type: 'object';
        visibility: 'PROMINENT';
    };
}
export declare const Shipment: Shipment;
