import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace TrackingEvent {
    type PropertyKeys = 'eventSequence' | 'eventTimestamp' | 'eventType' | 'geoPoint' | 'hoursSincePreviousEvent' | 'isLatestEvent' | 'latitude' | 'locationId' | 'longitude' | 'previousEventTimestamp' | 'shipmentId' | 'trackingEventId';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Sequence',
         *
         *   description: Position of this scan in the shipment's chronological scan history, starting at 1.
         */
        readonly eventSequence: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Time'
         */
        readonly eventTimestamp: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Type',
         *
         *   description: ORDER_CREATED, PICKED_UP, DEPARTED_HUB, IN_TRANSIT, ARRIVED_HUB, OUT_FOR_DELIVERY, DELIVERY_ATTEMPTED or DELIVERED.
         */
        readonly eventType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Scan Position',
         *
         *   description: Where the scan was recorded.
         */
        readonly geoPoint: $PropType['geopoint'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Dwell Since Previous Scan',
         *
         *   description: Hours elapsed between the previous scan and this one. Large values indicate where the shipment sat idle.
         */
        readonly hoursSincePreviousEvent: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Is Latest Scan',
         *
         *   description: True for the most recent scan on the shipment.
         */
        readonly isLatestEvent: $PropType['boolean'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Latitude'
         */
        readonly latitude: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Location ID'
         */
        readonly locationId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Longitude'
         */
        readonly longitude: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Previous Scan Time'
         */
        readonly previousEventTimestamp: $PropType['timestamp'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Shipment ID'
         */
        readonly shipmentId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Tracking Event ID'
         */
        readonly trackingEventId: $PropType['string'];
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<TrackingEvent, TrackingEvent.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof TrackingEvent.Props = keyof TrackingEvent.Props> = $Osdk.Instance<TrackingEvent, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof TrackingEvent.Props = keyof TrackingEvent.Props> = OsdkInstance<OPTIONS, K>;
}
export interface TrackingEvent extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'TrackingEvent';
    primaryKeyApiName: 'trackingEventId';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: TrackingEvent.ObjectSet;
        props: TrackingEvent.Props;
        linksType: TrackingEvent.Links;
        strictProps: TrackingEvent.StrictProps;
        apiName: 'TrackingEvent';
        description: "A single scan or telemetry reading on a shipment's journey. Ordered by sequence within each shipment and carrying the dwell time since the previous scan, so the whole journey reads as a timeline and idle periods are visible.";
        displayName: 'Tracking Event';
        icon: {
            type: 'blueprint';
            color: '#2D72D2';
            name: 'path-search';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'Tracking Events';
        primaryKeyApiName: 'trackingEventId';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Sequence',
             *
             *   description: Position of this scan in the shipment's chronological scan history, starting at 1.
             */
            eventSequence: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Time'
             */
            eventTimestamp: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Type',
             *
             *   description: ORDER_CREATED, PICKED_UP, DEPARTED_HUB, IN_TRANSIT, ARRIVED_HUB, OUT_FOR_DELIVERY, DELIVERY_ATTEMPTED or DELIVERED.
             */
            eventType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Scan Position',
             *
             *   description: Where the scan was recorded.
             */
            geoPoint: $PropertyDef<'geopoint', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Dwell Since Previous Scan',
             *
             *   description: Hours elapsed between the previous scan and this one. Large values indicate where the shipment sat idle.
             */
            hoursSincePreviousEvent: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Is Latest Scan',
             *
             *   description: True for the most recent scan on the shipment.
             */
            isLatestEvent: $PropertyDef<'boolean', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Latitude'
             */
            latitude: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Location ID'
             */
            locationId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Longitude'
             */
            longitude: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Previous Scan Time'
             */
            previousEventTimestamp: $PropertyDef<'timestamp', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Shipment ID'
             */
            shipmentId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Tracking Event ID'
             */
            trackingEventId: $PropertyDef<'string', 'non-nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.31029782-1d7a-4e2f-bcc7-a1a1c0e249e5';
        status: 'EXPERIMENTAL';
        titleProperty: 'eventType';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const TrackingEvent: TrackingEvent;
