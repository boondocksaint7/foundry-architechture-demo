export type $ExpectedClientVersion = '2.60.0';
export declare const $osdkMetadata: {
    extraUserAgent: string;
};
export declare const $ontologyRid = "ri.ontology.main.ontology.988487dd-4722-4bf8-84e0-8471eb6d8479";
/**
 * The RID of the Foundry branch this SDK was generated against, or
 * `undefined` if it was generated against the main branch.
 */
export declare const $branch: string | undefined;
